Telecom Map — versión web para iPhone

Abre index.html en un navegador compatible. La interfaz permite visualizar el registro de ejemplo,
filtrar registros e importar JSON/CSV.

Para usarla como app en iPhone:
1. Aloja estos archivos en un sitio web/servidor.
2. Ábrelo en Safari.
3. Pulsa Compartir → Añadir a pantalla de inicio.

Nota: la versión base visualiza únicamente las coordenadas proporcionadas en los registros.
